function conta(conta) {

    let num = 1;
    while ( conta <= num) {
        console.log(num);
        num++;
    }
    
}
let contador = 5;

while (contador>4) {
    console.log(contador);
    contador--;
}
import prompt from "prompt-sync";
let ler=prompt();
import { batata } from "../EX5/progF.js";

console.log("diga um numero");
let x=Number(ler());

let x2 = 100000 ;

while ( x2 = x ) {

    console.log( x2 + " gay" );
    x++;
    process.stdout.write ( x + '  M.T.H  ' );
}
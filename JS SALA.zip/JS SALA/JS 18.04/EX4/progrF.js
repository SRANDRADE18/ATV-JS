export function batata(cont,cont2) {
    for (let contador = cont; contador <= cont2 ; contador++) {
        if (contador%2 == 0) {
            console.log(contador);
        }
    }
}
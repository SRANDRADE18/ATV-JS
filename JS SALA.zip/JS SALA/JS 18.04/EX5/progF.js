export function batata(cont) {
    for (let contador = 1; contador <= cont; contador++) {

        console.log(" gay");

        process.stdout.write('M.T.H'); 
    }

}
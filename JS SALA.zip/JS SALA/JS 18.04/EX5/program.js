import prompt from 'prompt-sync';
import { batata } from './progF.js';

let ler=prompt();

console.log('primeiro numero');
let ny=Number(ler());

batata(ny)



function contar(conta) {
    
    let num= 0;
    while ( conta <= num) {
        console.log(num);
        num--;
    }
    
    }
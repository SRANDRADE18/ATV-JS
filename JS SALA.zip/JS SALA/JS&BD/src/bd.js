import conexao from "./conexao.js";

export async function inserirAluno(nome,chamada,turma,ano,genero,nascimento)
{
    let comando = 
        `   INSERT INTO tb_aluno (nm_aluno, nr_chamada, ds_turma, nr_ano, ds_genero, dt_nascimento) 
        VALUES (?, ?, ?, ?, ?, ?)`;
    
        let resp = await conexao.query(comando,[nome,chamada,turma,ano,genero,nascimento]);
}

export async function listarAlunos()
{
    let comando = `select * from tb_aluno`;

    let resp = await conexao.query(comando,[]);
    let dados = resp[0];
    return dados;
}

export async function listarAlunosPorano(ano){
    let comando = `select * from tb_aluno where nr_ano = ?`;

    let resp = await conexao.query(comando,[ano]);
    let dados = resp[0];
    
    return dados;
}

export async function buscarAlunoPorNome(nome){
    let comando  = `select * from tb_aluno where nm_aluno = ?`;

    let resp = await conexao.query(comando, [nome]);
    let dados = resp[0];

    return dados;
}
import mysql2 from 'mysql2/promise'
import { userInfo } from 'os'

let conexao = await mysql2.createConnection(
    {
        host:'localhost',
        user: 'root',
        password:'4587',
        database: 'infoB_db'
    }
)
export default conexao;
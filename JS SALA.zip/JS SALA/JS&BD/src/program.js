import { log } from "console";
import { inserirAluno,listarAlunos,listarAlunosPorano } from "./bd.js";

import prompt from "prompt-sync";
let ler=prompt();

console.log('Informe o nome:');
let nome = ler();

console.log('\nInforme a turma:');
let turma = ler();

console.log('\nInforme a chamada:');
let chamada = Number(ler());

console.log('\nInforme o ano:');
let ano = Number(ler());

console.log('\nInforme o genero:');
let genero = ler();

console.log('\nInforme a data de nascimento:');
let nasc = ler();

let info= await inserirAluno(nome,chamada,turma,ano,genero,nasc);
console.log('aluno inserido com sucesso');

console.log();
console.log();
console.log();
console.log('aluno cadastrado:'+ nome);
let alunos=await listarAlunos();

for(let item of alunos){
    console.log(item.id_aluno+'.'+item.nm_aluno+'-'+item.ds_turma+'-'+item.dt_nascimento.toLocaleDateString());
}
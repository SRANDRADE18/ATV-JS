import prompt from "prompt-sync";
import { separar } from "./EX4FF.js";
let ler =prompt();


console.log('informe a palavra');
let a = ler();

separar(a);
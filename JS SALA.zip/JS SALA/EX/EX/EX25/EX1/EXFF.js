export function SomarAte(number) {
  
let cont=1;
let soma=0;

while ( cont <= number) {
    soma = soma + cont;
    cont++;    
}
 
console.log("soma " + soma);

}


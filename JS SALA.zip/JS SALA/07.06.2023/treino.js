import prompt from 'prompt-sync';
let ler=prompt();

let x=[];
let a=5;
for (let index = 0; index <= a ; index++) {
    console.log('digite alguma coisa');
    x[index]=Number(ler());
}

console.log('voce digitou?');
for (let item of x) {
    let av = x;
     console.log(av + []);
 }


  
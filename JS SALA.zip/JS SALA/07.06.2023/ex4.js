import prompt from 'prompt-sync';
let ler=prompt();

let x = [];
let xv = [];
let a = 6;

for (let i = 0; i <= a; i++) {
    console.log('informe o numero ');   
    x[i]=ler();
}

  
for (let aa = 0; aa <= a; aa++) {
    console.log('informe a posição');
    x + xv[aa]+ler();
} 

console.log('voce digitou?');
for (let item of x) {
   let av = x;
    console.log(av + []);
}